#pragma once
#include "main.h"

#define PORT_INERTIAL 6

#define PORT_INTAKE_LEFT -1
#define PORT_INTAKE_RIGHT (10)

#define PORT_DRIVE_LEFT_FRONT (-9)  //reversed
#define PORT_DRIVE_LEFT_TOP 8
#define PORT_DRIVE_LEFT_BOTTOM (-7) //reversed
#define PORT_DRIVE_RIGHT_FRONT 2
#define PORT_DRIVE_RIGHT_TOP (-3) //reversed
#define PORT_DRIVE_RIGHT_BOTTOM 4

#define PORT_ADI_LATCH_LEFT 'A'
#define PORT_ADI_LATCH_RIGHT 'H'
#define PORT_ADI_DOINKY 'B'
