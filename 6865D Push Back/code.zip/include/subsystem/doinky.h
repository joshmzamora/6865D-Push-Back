#pragma once
#include "main.h"

void runDoinkyToggle();
void engageDoinky();
void disengageDoinky();
bool isDoinked();

