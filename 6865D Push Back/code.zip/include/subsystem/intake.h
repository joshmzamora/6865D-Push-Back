#pragma once
#include "main.h"

void intakeIn();
void intakeOut();
void intakeStop();
void runIntake();
