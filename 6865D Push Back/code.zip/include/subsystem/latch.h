#pragma once
#include "main.h"
void runLatchToggle();
void engageLatch();
void disengageLatch();
bool isLatched();
