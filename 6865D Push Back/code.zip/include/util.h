#pragma once
#include "main.h"

double returnExponential(int axisValue, int type, float t);

template <typename T> int sgn(T val);